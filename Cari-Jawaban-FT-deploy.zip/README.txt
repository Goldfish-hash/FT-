CARI JAWABAN FT - paket deploy
|•Dibuat oleh>>IkmalKamarulloh•|

ISI PAKET
- index.html  : seluruh aplikasi (data 6.320 soal, gambar, dan kode jadi satu file)

CARA DEPLOY (pilih salah satu)
1. Hosting biasa / cPanel : extract zip, upload index.html ke folder public_html (atau subfolder).
2. Netlify Drop           : buka app.netlify.com/drop, seret folder hasil extract ke halaman itu.
3. GitHub Pages           : upload index.html ke repository, lalu Settings > Pages > pilih branch main.
4. Lokal                  : klik dua kali index.html (tanpa server pun jalan).

CATATAN
- Tidak butuh PHP, database, atau server khusus. Semua jalan di browser.
- Font Plus Jakarta Sans dan fitur baca foto soal (OCR) butuh internet. Tanpa internet, font memakai bawaan HP dan fitur foto tidak aktif; pencarian tetap jalan.
- Untuk update soal, data diganti lewat pembuatan ulang index.html (minta ke pembuatnya).
